import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControls, Maybe } from '../../home/home.component';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { NgForOf } from '@angular/common';
import { InputComponent } from "../../shared/input/input.component";
import { ComboboxComponent } from "../../shared/combobox/combobox.component";
import { ComboOption } from '../../models/comboOption';
import { ButtonComponent } from "../../shared/button/button.component";
import { Category } from '../../services/category';
import { Subscription } from 'rxjs';
import { Product } from '../../services/product';
import { Bill } from '../../services/bill';

export interface CustomerForm {
  name: string;
  email: string;
  contactNumber: string;
  paymentMethod: ComboOption | null;
}

export interface ProductForm {
  category: ComboOption | null;
  product: ComboOption | null;
  price: number;
  quantity: number;
  total: number;
}

export interface MainForm {
  customer: CustomerForm;
  product: ProductForm;
  items: ProductForm[];
}

type CustomerFormGroup = FormGroup<FormControls<CustomerForm>>;
type ProductFormGroup = FormGroup<FormControls<ProductForm>>;

type MainFormGroup = FormGroup<{
  customer: CustomerFormGroup;
  product: ProductFormGroup;
  items: FormControl<ProductForm[]>;
}>;


@Component({
  selector: 'app-order-manage',
  standalone: true,
  imports: [ReactiveFormsModule, NgForOf, InputComponent, ComboboxComponent, ButtonComponent],
  templateUrl: './order-manage.component.html',
  styleUrl: './order-manage.component.scss'
})
export class OrderManageComponent implements OnInit, OnDestroy {

  form!: MainFormGroup;

  listPaymentMethod: ComboOption[] = []
  listCategory: ComboOption[] = []
  listProducts: ComboOption[] = []

  subscription: Subscription[] = []

  constructor(private apiCategory: Category, private apiProduct: Product, private apiBill: Bill) { }

  async ngOnInit() {
    this.createForm();
    this.listCategory = (await this.apiCategory.getCategory(true)).map((data) => {
      return {
        id: data.id,
        value: data.name
      }
    });
    this.listPaymentMethod.push({ id: 1, value: 'Cash' }, { id: 2, value: 'Card' });
    this.listeners()
  }

  ngOnDestroy(): void {
    this.subscription.forEach(e => e.unsubscribe())
  }

  listeners() {
    const s1 = this.form.controls.product.controls.category.valueChanges.subscribe(async value => {
      this.listProducts = (await this.apiProduct.getProductsByCategory(Number(value?.id ?? 0))).map((data) => {
        return {
          id: data.id,
          value: data.name
        }
      });
    });
    s1 && this.subscription.push(s1);

    const s2 = this.form.controls.product.controls.product.valueChanges.subscribe(async value => {
      const response = await this.apiProduct.getById(Number(value?.id ?? 0))
      if (response?.price) {
        this.form.controls.product.controls.price.setValue(response.price);
        this.form.controls.product.controls.quantity.setValue(1);
      }

    });
    s2 && this.subscription.push(s2);
  }

  createForm() {
    this.form = new FormGroup({
      customer: new FormGroup<FormControls<CustomerForm>>({
        name: new FormControl('', { nonNullable: true, validators: Validators.required }),
        email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] }),
        contactNumber: new FormControl('', { nonNullable: true, validators: Validators.required }),
        paymentMethod: new FormControl(null, { nonNullable: true, validators: Validators.required }),
      }),
      product: new FormGroup<FormControls<ProductForm>>({
        category: new FormControl(null, { nonNullable: true, validators: [Validators.required] }),
        product: new FormControl(null, { nonNullable: true, validators: [Validators.required] }),
        price: new FormControl(0, { nonNullable: true }),
        quantity: new FormControl(0, { nonNullable: true }),
        total: new FormControl(0, { nonNullable: true }),
      }),
      items: new FormControl<ProductForm[]>([], { nonNullable: true }),
    });
  }

  addProduct() {
    const product = this.form.controls.product.getRawValue();
    product.total = product.price * product.quantity;
    this.form.controls.product.reset();
    this.form.controls.items.setValue([
      ...this.form.controls.items.value,
      product
    ]);
  }

  removeProduct(index: number) {
    this.form.controls.items.setValue(
      this.form.controls.items.value.filter((_, i) => i !== index)
    );
  }

  get grandTotal() {
    return this.form.controls.items.value
      .reduce((acc, p) => acc + p.total, 0);
  }

  generateAndGetPdf() {
    const customer = this.form.controls.customer;
    const details = this.form.controls.items.getRawValue();
    if (customer.invalid) return;

    try {
      const payload = {
        fileName: 'test',
        name: customer?.value?.name ?? '',
        email: customer?.value?.email ?? '',
        contactNumber: customer?.value?.contactNumber ?? '',
        paymentMethod: customer?.value?.paymentMethod?.value ?? '',
        totalAmount: this.grandTotal.toString(),
        productDetails: JSON.stringify(details.map((data) => {
          return {
            id: 999,
            name: data.product?.value,
            category: data.category?.value,
            quantity: data.quantity,
            price: data.price,
            total: data.total
          }
        }))
      }
      this.apiBill.generateReport(payload).then(async data => {
        const blob = await this.apiBill.getPdf(data.uuid)
        const url = window.URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = `${data.uuid}.pdf`;
        a.click();

        window.URL.revokeObjectURL(url);

      }).finally(() => {
        this.form.reset()
      })
    } catch (error) {

    }
  }


}


