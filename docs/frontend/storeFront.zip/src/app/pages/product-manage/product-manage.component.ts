import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, Validators } from '@angular/forms';
import { FormControls, Maybe } from '../../home/home.component';
import { Product } from '../../services/product';
import { ButtonComponent } from "../../shared/button/button.component";
import { ModalComponent } from "../../shared/modal/modal.component";
import { InputComponent } from "../../shared/input/input.component";
import { NgFor, NgIf } from '@angular/common';
import { CategoryFilterPipe } from '../../core/pipes/categoryFilter-pipe';
import { ToggleSwitchComponent } from "../../shared/toggle-switch/toggle-switch.component";
import { Category } from '../../services/category';
import { ComboOption } from '../../models/comboOption';
import { ComboboxComponent } from "../../shared/combobox/combobox.component";


export interface ProductModel {
  id: number | null;
  name: string;
  description: string;
  price: number;
  status: string | null;
  category: ComboOption | null
}


type ProductFormGroup = FormGroup<FormControls<ProductModel>>;

export type ModelModalC = 'newProduct' | 'editProduct' | 'deleteProduct'

@Component({
  selector: 'app-product-manage',
  standalone: true,
  imports: [ButtonComponent, FormsModule, ModalComponent, InputComponent, NgIf, NgFor, CategoryFilterPipe, ComboboxComponent],
  templateUrl: './product-manage.component.html',
  styleUrl: './product-manage.component.scss'
})
export class ProductManageComponent {
  // VALUES
  products: ProductModel[] = [];
  filterText = '';
  openModal: Maybe<ModelModalC>;
  listCategories: Array<ComboOption> = []


  // FORMS
  productForm: Maybe<ProductFormGroup>


  constructor(
    private api: Product,
    private apiCategory: Category
  ) { }

  async ngOnInit() {
    await this.loadProducts();
  }

  createProductForm() {
    this.productForm = new FormGroup<FormControls<ProductModel>>({
      id: new FormControl(0, []),
      status: new FormControl('', []),
      name: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required]
      }),
      price: new FormControl(0, {
        nonNullable: true,
        validators: [Validators.required, Validators.min(1)]
      }),
      category: new FormControl(null, {
        nonNullable: true,
        validators: [Validators.required]
      }),
      description: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required]
      })
    });
  }

  async loadProducts() {
    const response = await this.api.getProduct();
    this.products = response.map((data) => {
      return {
        ...data,
        category: {
          id: data.categoryId,
          value: data.categoryName
        }
      }
    })
  }

  async openModalC(type: ModelModalC, product?: ProductModel) {
    // getters
    this.createProductForm();
    this.listCategories = (await this.apiCategory.getCategory()).map((data) => ({
      id: data.id,
      value: data.name
    }));

    if ((['editProduct', 'deleteProduct'].includes(type)) && product) {
      this.productForm?.patchValue(product);
    }
    this.openModal = type;
  }

  async callService(type: ModelModalC) {

    try {
      this.openModal = type;
      if (this.productForm?.invalid) throw new Error("Not edit data found");
      const raw = this.productForm?.getRawValue() as ProductModel
      switch (type) {
        case 'newProduct':
          await this.api.addProduct(raw);
          break;
        case 'editProduct':
          await this.api.updateProduct(raw);
          break;
        case 'deleteProduct':
          const id = raw?.id ?? 0
          await this.api.deleteProduct(id);
          break;
      }
      this.openModal = undefined;
      await this.loadProducts()
    } catch (error) {
      console.log(error);

    }

  }
}
