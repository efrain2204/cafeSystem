import { HttpErrorResponse, type HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

export const authInterceptor: HttpInterceptorFn = (req, next) => {

  const router = inject(Router)

  const token = localStorage.getItem('token');
  if (!token) {
    return next(req);
  }

  req = req.clone({
    setHeaders: { Authorization: `Bearer ${token}` }
  });

  return next(req).pipe(
    catchError((err) => {
      if (err instanceof HttpErrorResponse) {
        if (err.status === 401 || err.status === 403) {
          if (router.url === '/') { }
          else {
            localStorage.clear();
            router.navigate(['/']);
          }
        }
      }
      return throwError(err);
    })
  );
};
