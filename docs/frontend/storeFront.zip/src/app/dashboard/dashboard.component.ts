import { Component, AfterViewInit, OnInit } from '@angular/core';
import { Dashboard } from '../services/dashboard';
@Component({
	selector: 'app-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

	data: any;

	constructor(private api: Dashboard) {
	}

	async ngOnInit() {
		this.data = await this.api.getDetails();
	}

	viewDetails(type: 'product' | 'bill' | 'category') {
		console.log('Ver detalles de:', type);

		// Ejemplos:
		// this.router.navigate(['/details', type]);
		// this.openModal(type);
	}

}
