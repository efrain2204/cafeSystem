export interface ComboOption<T = string | number> {
  id: T;
  value: string;
}