import { Injectable } from '@angular/core';
import { HttpService } from './HttpService';

@Injectable({
  providedIn: 'root'
})
export class Dashboard {

  constructor(private http: HttpService) {
  }

  getDetails(): Promise<any> {
    return this.http.get('/dashboard/details')
  }

}
