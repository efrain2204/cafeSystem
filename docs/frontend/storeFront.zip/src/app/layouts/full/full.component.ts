import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { AppSidebarComponent } from './sidebar/sidebar.component';


@Component({
  selector: 'app-full-layout',
  standalone: true,
  templateUrl: 'full.component.html',
  styleUrls: ['./full.component.scss'],
  imports: [RouterOutlet, HeaderComponent, AppSidebarComponent]
})
export class FullComponent {
  
  sidebarOpen = false;

  toggleSidebar() {
    this.sidebarOpen = !this.sidebarOpen;
  }
}
