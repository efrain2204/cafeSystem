import { Injectable } from '@angular/core';
import { HttpService } from './HttpService';

export interface BillInterface {
  id: number;
  uui: string;
  name: string;
  email: string | null;
  contactNumber: string;
  paymentMethod: 'Cash' | 'Card' | string;
  total: number;
  productDetails: ProductDetail[];
  createdBy: string;
}

export interface ProductDetail {
  id: number;
  name: string;
  price: number;
  total: number;
  category: string;
  quantity: number;
}

@Injectable({
  providedIn: 'root'
})
export class Bill {

  constructor(private http: HttpService) { }

  generateReport(data: any): Promise<any> {
    return this.http.post('/bill/generateReport', data)
  }

  getPdf(data: any): Promise<any> {
    const payload = {
      uuid: data
    }
    return this.http.postFile('/bill/getPdf', payload)
  }

  getBills(): Promise<any[]> {
    return this.http.get('/bill/getBills')
  }

  deleteBill(id: number) {
    const url = `/bill/delete/${id}`;
    return this.http.post(url, {});
  }
}
