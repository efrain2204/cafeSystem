import { Component, OnInit } from '@angular/core';
import { BestSellerComponent } from "../best-seller/best-seller.component";
import { ModalComponent } from "../shared/modal/modal.component";
import { CommonModule, NgIf } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { InputComponent } from "../shared/input/input.component";
import { ButtonComponent } from "../shared/button/button.component";
import { Home } from '../services/home';
import { Router } from '@angular/router';

export type Maybe<T> = T | null | undefined;
export type FormControls<T> = {
  [K in keyof T]: FormControl<T[K]>;
};

export type ModeModal = 'signUp' | 'login' | 'forgotPassword'


export interface SignUpModel {
  number: string;
  email: string;
  name: string;
  password: string;
}

export interface ForgotPwdModel {
  email: string
}

export interface LoginModel {
  email: string
  password: string;
}

type SignUpFormGroup = FormGroup<FormControls<SignUpModel>>;
type ForgotPwdFormGroup = FormGroup<FormControls<ForgotPwdModel>>;
type LoginFormGroup = FormGroup<FormControls<LoginModel>>;


@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  imports: [BestSellerComponent, ModalComponent, NgIf, InputComponent, ButtonComponent]
})
export class HomeComponent implements OnInit {

  modeModal: Maybe<ModeModal>
  signUpForm: Maybe<SignUpFormGroup>;
  forgotPwdForm: Maybe<ForgotPwdFormGroup>;
  loginForm: Maybe<LoginFormGroup>;
  title = ''

  constructor(private api: Home, private router: Router) { }

  async ngOnInit() {
    try {
      await this.api.checkToken()
      this.router.navigate(['cafe/dashboard']);
    } catch (error) {

    }
  }

  createSignUpForm() {
    this.signUpForm = new FormGroup<FormControls<SignUpModel>>({
      name: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required]
      }),
      email: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required, Validators.email]
      }),
      number: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required]
      }),
      password: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required]
      })
    });
  }

  createForgotPwdForm() {
    this.forgotPwdForm = new FormGroup<FormControls<ForgotPwdModel>>({
      email: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required, Validators.email]
      }),
    })
  }

  createLoginForm() {
    this.loginForm = new FormGroup<FormControls<LoginModel>>({
      email: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required, Validators.email]
      }),
      password: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required]
      })
    });
  }

  async callService(type: ModeModal) {
    try {
      switch (type) {
        case 'signUp':
          if (!this.signUpForm) return

          const rawS = this.signUpForm.getRawValue() as SignUpModel;
          await this.api.signup(rawS);
          break;
        case 'forgotPassword':
          if (!this.forgotPwdForm) return;

          const rawF = this.forgotPwdForm.getRawValue() as ForgotPwdModel;
          await this.api.forgotPwd(rawF);
          break;
        case 'login':
          if (!this.loginForm) return;

          const rawL = this.loginForm.getRawValue() as LoginModel;
          const response = await this.api.login(rawL);
          localStorage.setItem("token", response.token)
          this.router.navigate(['/cafe/dashboard'])
          break;
      }
      this.modeModal = undefined
    } catch (error) {
      console.log(error);

    }
  }

  openModal(type: ModeModal) {
    switch (type) {
      case 'signUp':
        this.title= 'Register'
        this.createSignUpForm()
        break;
      case 'forgotPassword':
        this.title= 'Forgot Password'
        this.createForgotPwdForm()
        break;
      case 'login':
        this.title = 'Login'
        this.createLoginForm();
        break;
    }
    this.modeModal = type
  }

  closeAndDeleteForms() {
    this.signUpForm?.reset();
    this.forgotPwdForm?.reset();
    this.loginForm?.reset();

    this.signUpForm = undefined;
    this.forgotPwdForm = undefined;
    this.loginForm = undefined;
    this.modeModal = undefined;
  }

}
