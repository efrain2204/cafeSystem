import { Pipe, type PipeTransform } from '@angular/core';

@Pipe({
  name: 'CategoryFilter',
  standalone: true,
})
export class CategoryFilterPipe implements PipeTransform {

  transform(listData: any[], filter: string): any[] {
    if (!filter) return listData;

    return listData.filter(c =>
      c.name.toLowerCase().includes(filter.toLowerCase())
    );
  }

}
