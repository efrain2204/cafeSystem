import { NgFor } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

export interface SidebarMenuItem {
  label: string;
  icon?: string;
  route: string;
  exact?: boolean;
}

export const SIDEBAR_MENU: SidebarMenuItem[] = [
  {
    label: 'Dashboard',
    icon: '🏠',
    route: '/cafe/dashboard',
    exact: true
  },
  {
    label: 'Categories',
    icon: '📂',
    route: '/cafe/category'
  },
  {
    label: 'Products',
    icon: '📦',
    route: '/cafe/product'
  },
  {
    label: 'Order',
    icon: '🛒',
    route: '/cafe/order'
  },
  {
    label: 'Bill',
    icon: '📝',
    route: '/cafe/bill'
  },
  {
    label: 'User',
    icon: '👥',
    route: '/cafe/user'
  }
];


@Component({
  selector: 'app-sidebar',
  standalone: true,
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  imports: [NgFor, RouterModule]
})
export class AppSidebarComponent {

  menu: SidebarMenuItem[] = SIDEBAR_MENU;

  constructor(public router: Router) { }

}
