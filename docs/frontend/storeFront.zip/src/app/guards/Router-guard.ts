import { inject } from '@angular/core';
import { Router, type CanActivateFn } from '@angular/router';
import { auth } from '../services/auth';
import { jwtDecode } from 'jwt-decode';

export const routerGuard: CanActivateFn = (route, state) => {
  const authS = inject(auth);
  const router = inject(Router);

  let expectedRoleArray: any = route.data;
  expectedRoleArray = expectedRoleArray['expectedRole']
  const token: string = localStorage.getItem('token') ?? '';

  let tokenPayload: any;
  try {
    tokenPayload = jwtDecode(token);
  } catch (error) {
    localStorage.clear();
    router.navigate(['/']);
  }
  let expectedRole = '';
  for (let i = 0; i < expectedRoleArray.length; i++) {
    if (expectedRoleArray[i] === tokenPayload.role) {
      expectedRole = tokenPayload.role
    }
  }
  if (tokenPayload.role == 'user' || tokenPayload.role == 'admin') {
    if (authS.isAuthenticated() && tokenPayload.role === expectedRole) {
      return true
    }
    router.navigate(['/cafe/dashboard'])
    return false;
  } else {
    router.navigate(['/']);
    localStorage.clear();
    return false;
  }
};
