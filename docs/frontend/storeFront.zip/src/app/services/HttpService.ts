import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.prod';
import { HttpClient, HttpParams } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  private readonly api = environment.apiUrl;

  constructor(private http: HttpClient) { }

  async get<T>(url: string, params?: Record<string, any>): Promise<T> {
    return await firstValueFrom(
      this.http.get<T>(`${this.api}${url}`, {
        params: new HttpParams({ fromObject: params }),
      })
    );
  }

  async post<T>(url: string, body: unknown): Promise<T> {
    return await firstValueFrom(
      this.http.post<T>(`${this.api}${url}`, body)
    );
  }

  postFile(url: string, body: unknown): Promise<Blob> {
    return firstValueFrom(
      this.http.post(`${this.api}${url}`, body, {
        responseType: 'blob'
      })
    );
  }

  async put<T>(url: string, body: unknown): Promise<T> {
    return await firstValueFrom(
      this.http.put<T>(`${this.api}${url}`, body)
    );
  }

  async delete<T>(url: string): Promise<T> {
    return await firstValueFrom(
      this.http.delete<T>(`${this.api}${url}`)
    );
  }

}
