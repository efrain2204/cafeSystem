import { FormGroup } from "@angular/forms";
import { FormControls } from "../home/home.component";

export interface ChangePasswordModel {
    oldPwd: string;
    newPwd: string;
    reNewPwd: string;
}

export type ChangePwdGroup = FormGroup<FormControls<ChangePasswordModel>>;