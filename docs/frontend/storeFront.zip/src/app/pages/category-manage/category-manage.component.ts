import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CategoryFilterPipe } from '../../core/pipes/categoryFilter-pipe';
import { Category } from '../../services/category';
import { ButtonComponent } from "../../shared/button/button.component";
import { ModalComponent } from "../../shared/modal/modal.component";
import { Maybe } from '../../home/home.component';
import { InputComponent } from "../../shared/input/input.component";

export interface CategoryModel {
  id: number;
  name: string;
}

export type ModelModalC = 'newCategory' | 'editCategory'

@Component({
  selector: 'app-category-manage',
  standalone: true,
  imports: [CommonModule, FormsModule, CategoryFilterPipe, ButtonComponent, ModalComponent, InputComponent],
  templateUrl: './category-manage.component.html',
  styleUrl: './category-manage.component.scss'
})
export class CategoryManageComponent {
  categories: CategoryModel[] = [];
  filterText = '';
  loading = false;

  openModal: Maybe<ModelModalC>;

  nameControl = new FormControl<string>('', Validators.required);
  editData: Maybe<CategoryModel>

  constructor(
    private api: Category,
  ) { }

  async ngOnInit() {
    await this.loadCategories();
  }

  async loadCategories() {
    this.loading = true;
    this.categories = await this.api.getCategory();
    this.loading = false;
  }

  openModalC(type: ModelModalC, category?: CategoryModel): void {
    this.openModal = type;
    if (type === 'editCategory' && category) {
      this.nameControl.setValue(category.name);
      this.editData = category
    } else {
      this.editData = undefined
    }
  }

  async callService(type: ModelModalC) {
    this.openModal = type;
    try {
      switch (type) {
        case 'newCategory':
          if (!this.nameControl.value) return
          const name = this.nameControl.value ?? ''
          await this.api.addCategory(name);
          await this.loadCategories()
          this.openModal = undefined;
          this.nameControl.reset();
          break;
        case 'editCategory':
          if (!this.editData) throw new Error("Not edit data found");
          const nameEdit = this.nameControl.value ?? ''
          await this.api.updateCategory(this.editData.id, nameEdit);
          await this.loadCategories()
          this.openModal = undefined;
          this.nameControl.reset();
          break;
      }
    } catch (error) {
      console.log(error);

    }

  }
}
