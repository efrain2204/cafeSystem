import { Injectable } from '@angular/core';
import { HttpService } from './HttpService';
import { ForgotPwdModel, LoginModel, SignUpModel } from '../home/home.component';
import { ChangePasswordModel } from '../models/changePwd';

@Injectable({
  providedIn: 'root'
})
export class Home {
  constructor(private http: HttpService) { }

  signup(raw: SignUpModel): Promise<any> {
    const payload = {
      name: raw.name,
      contactNumber: raw.number,
      email: raw.email,
      password: raw.password
    }
    return this.http.post('/user/signup', payload)
  }

  forgotPwd(raw: ForgotPwdModel): Promise<any> {
    const payload = {
      email: raw.email,

    }
    return this.http.post('/user/forgotPassword', payload)
  }

  login(rawL: LoginModel): Promise<{ token: string }> {
    const payload = {
      email: rawL.email,
      password: rawL.password
    }
    return this.http.post('/user/login', payload)
  }

  checkToken(): Promise<any> {
    return this.http.get('/user/checkToken')
  }

  changePassword(rawChange: ChangePasswordModel) {
    const payload = {
      oldPassword: rawChange.oldPwd,
      newPassword: rawChange.newPwd
    }
    return this.http.post('/user/changePassword', payload)
  }

  getUsers(): Promise<any[]> {
    return this.http.get('/user/get')
  }

  updateStatus(id: number, status: string) {
    const payload = {
      id,
      status
    }
    return this.http.post('/user/update', payload)
  }

}
