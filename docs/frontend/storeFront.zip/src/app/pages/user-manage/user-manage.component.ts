import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { ToggleSwitchComponent } from "../../shared/toggle-switch/toggle-switch.component";
import { FormsModule } from '@angular/forms';
import { CategoryFilterPipe } from '../../core/pipes/categoryFilter-pipe';
import { Home } from '../../services/home';

export interface UserModel {
  id: number;
  name: string;
  email: string;
  contactNumber: number;
  status: string;
}

@Component({
  selector: 'app-user-manage',
  standalone: true,
  imports: [NgIf, NgFor, FormsModule, CategoryFilterPipe],
  templateUrl: './user-manage.component.html',
  styleUrl: './user-manage.component.scss'
})
export class UserManageComponent {
  // VALUES
  users: UserModel[] = [];
  filterText = '';

  constructor(
    private api: Home
  ) { }

  async ngOnInit() {
    await this.loadUsers();
  }

  async loadUsers() {
    this.users = await this.api.getUsers();
  }

  async onToggle(event: Event, id: number) {
    const checked = (event.target as HTMLInputElement).checked;
    await this.api.updateStatus(id, checked ? 'true' : 'false');
  }

  async callService() {

  }
}
