import { Injectable } from '@angular/core';
import { HttpService } from './HttpService';
import { CategoryModel } from '../pages/category-manage/category-manage.component';

@Injectable({
  providedIn: 'root'
})
export class Category {

  constructor(private http: HttpService) { }

  getCategory(status: boolean = false): Promise<Array<{
    id: number,
    name: string
  }>> {
    let url = status ? '/category/get?filterValue=true' : '/category/get'
    return this.http.get(url)
  }

  addCategory(name: string): Promise<any> {
    const payload = {
      name,
    }
    return this.http.post('/category/add', payload)
  }

  updateCategory(id: number, name: string): Promise<any> {
    const payload = {
      id,
      name,
    }
    return this.http.post('/category/update', payload)
  }

}
