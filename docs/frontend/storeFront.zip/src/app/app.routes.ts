import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { FullComponent } from './layouts/full/full.component';
import { routerGuard } from './guards/Router-guard';

export const routes: Routes = [
    { path: '', component: HomeComponent },
    {
        path: 'cafe',
        component: FullComponent,
        children: [
            {
                path: 'dashboard',
                loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule),
                canActivate: [routerGuard],
                data: {
                    expectedRole: ['admin', 'user']
                }
            },
            {
                path: 'category',
                loadComponent: () => import('./pages/category-manage/category-manage.component').then(c => c.CategoryManageComponent),
                canActivate: [routerGuard],
                data: {
                    expectedRole: ['admin']
                }
            },
            {
                path: 'product',
                loadComponent: () => import('./pages/product-manage/product-manage.component').then(c => c.ProductManageComponent),
                canActivate: [routerGuard],
                data: {
                    expectedRole: ['admin']
                }
            },
            {
                path: 'order',
                loadComponent: () => import('./pages/order-manage/order-manage.component').then(c => c.OrderManageComponent),
                canActivate: [routerGuard],
                data: {
                    expectedRole: ['admin', 'user']
                }
            },
            {
                path: 'bill',
                loadComponent: () => import('./pages/bill-manage/bill-manage.component').then(c => c.BillManageComponent),
                canActivate: [routerGuard],
                data: {
                    expectedRole: ['admin', 'user']
                }
            },
            {
                path: 'user',
                loadComponent: () => import('./pages/user-manage/user-manage.component').then(c => c.UserManageComponent),
                canActivate: [routerGuard],
                data: {
                    expectedRole: ['admin']
                }
            },
            {
                path: '',
                redirectTo: 'dashboard',
                pathMatch: 'full',
            },
        ]
    },
    { path: '**', component: HomeComponent }
];
