import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { ButtonComponent } from "../../shared/button/button.component";
import { FormsModule, NgModel, ReactiveFormsModule } from '@angular/forms';
import { ComboOption } from '../../models/comboOption';
import { Maybe } from '../../home/home.component';
import { Bill, BillInterface, ProductDetail } from '../../services/bill';
import { CategoryFilterPipe } from '../../core/pipes/categoryFilter-pipe';
import { ModalComponent } from "../../shared/modal/modal.component";

export type ModelModalB = 'viewData' | 'download' | 'delete'

@Component({
  selector: 'app-bill-manage',
  standalone: true,
  imports: [NgFor, ReactiveFormsModule, FormsModule, CategoryFilterPipe, NgIf, ModalComponent, ButtonComponent],
  templateUrl: './bill-manage.component.html',
  styleUrl: './bill-manage.component.scss'
})
export class BillManageComponent {

  // VALUES
  bills: BillInterface[] = [];
  billSelected: Maybe<BillInterface>
  filterText = '';
  openModal: Maybe<ModelModalB>;
  listCategories: Array<ComboOption> = []

  constructor(private api: Bill) { }


  async ngOnInit() {
    await this.loadBills();
  }

  async loadBills() {
    this.bills = (await this.api.getBills()).map((data) => {
      return {
        ...data,
        productDetails: JSON.parse(data.productDetails)
      }
    });
  }

  async openModalB(type: ModelModalB, bill: BillInterface) {
    this.billSelected = bill

    if (type === 'download') {
      await this.callService(type)
      return
    }

    this.openModal = type;
  }

  async callService(type: ModelModalB) {
    try {
      if (!this.billSelected) return
      if (type === 'delete') {
        await this.api.deleteBill(this.billSelected.id);
        this.openModal = undefined;
      } else if (type === 'download') {
        const blob = await this.api.getPdf(this.billSelected.uui)
        const url = window.URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = `${this.billSelected.uui}.pdf`;
        a.click();

        window.URL.revokeObjectURL(url);

        return;
      }
      await this.loadBills();

    } catch (error) {

    }
  }
}
