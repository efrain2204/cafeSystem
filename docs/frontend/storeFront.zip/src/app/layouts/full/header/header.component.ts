import { NgIf } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { ModalComponent } from '../../../shared/modal/modal.component';
import { FormControls, Maybe } from '../../../home/home.component';
import { ChangePasswordModel, ChangePwdGroup } from '../../../models/changePwd';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { InputComponent } from '../../../shared/input/input.component';
import { ButtonComponent } from '../../../shared/button/button.component';
import { Home } from '../../../services/home';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [NgIf, ModalComponent, InputComponent, ButtonComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {

  @Output()
  sideBarToggle = new EventEmitter();

  userMenuOpen = false;
  modeModal = false;

  changePwdForm: Maybe<ChangePwdGroup>


  constructor(private router: Router, private api: Home) { }

  createChangePwdForm() {
    this.changePwdForm = new FormGroup<FormControls<ChangePasswordModel>>({
      oldPwd: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required]
      }),
      newPwd: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required]
      }),
      reNewPwd: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required]
      })
    })
  }

  async callService() {
    try {
      if (!this.changePwdForm) return;

      const rawChange = this.changePwdForm.getRawValue() as ChangePasswordModel;

      if (rawChange.newPwd !== rawChange.reNewPwd) throw new Error("Diferent pwd");
      await this.api.changePassword(rawChange)

      this.changePwdForm = undefined;
      this.modeModal = false
    } catch (error) {
      console.log(error);
      
    }
  }

  toggleSidebar() {
    this.sideBarToggle.emit()
  }

  toggleUserMenu(event: MouseEvent) {
    event.stopPropagation();
    this.userMenuOpen = !this.userMenuOpen;
  }

  changePassword() {
    this.userMenuOpen = false;
    this.modeModal = true
    this.createChangePwdForm()
  }

  logout() {
    localStorage.clear()
    this.router.navigate(['/']);
    this.userMenuOpen = false;
  }
}
