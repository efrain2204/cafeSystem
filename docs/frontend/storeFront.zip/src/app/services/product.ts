import { Injectable } from '@angular/core';
import { HttpService } from './HttpService';
import { ProductModel } from '../pages/product-manage/product-manage.component';

@Injectable({
  providedIn: 'root'
})
export class Product {

  constructor(private http: HttpService) { }


  getProduct(): Promise<any[]> {
    return this.http.get('/product/get');
  }

  addProduct(rawP: ProductModel): Promise<any> {
    const payload = {
      categoryId: rawP.category?.id,
      name: rawP.name,
      description: rawP.description,
      price: Number(rawP.price)
    }
    return this.http.post('/product/add', payload)
  }

  updateProduct(rawP: ProductModel): Promise<any> {
    const payload = {
      id: rawP.id,
      name: rawP.name,
      description: rawP.description,
      price: Number(rawP.price),
      categoryId: rawP.category?.id
    }
    return this.http.post('/product/update', payload)
  }

  deleteProduct(id: number): Promise<any> {
    const url = `/product/delete/${id}`
    return this.http.post(url, {})
  }

  getProductsByCategory(id: number): Promise<any[]> {
    const url = `/product/getByCategory/${id}`
    return this.http.get(url)
  }

  getById(id: number): Promise<any> {
    const url = `/product/getById/${id}`
    return this.http.get(url)
  }

  updateStatusProduct(): Promise<any> {
    const payload = {
      status: "true",
      id: 3
    }
    return this.http.post('/product/updateStatus', payload)
  }

}
